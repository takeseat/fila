-- AlterTable
ALTER TABLE `restaurants` ADD COLUMN `calledAlertMinutes` INTEGER NULL,
    ADD COLUMN `waitingAlertMinutes` INTEGER NULL;
